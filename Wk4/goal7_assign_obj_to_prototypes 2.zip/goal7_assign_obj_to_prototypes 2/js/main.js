/**
 * Created by the JavaScript Development Team
 * Class: PWA
 * Goal: Goal7
 */
/* Devin M. Woodfork
 2/29/16
 OBJECTS.Person Assignment
 */

//*********** PSEUDO CODE ONLY

/*
 runUpdate function at intervals of 30 times a second

 use a for loop to cycle through person object's action attribute

generate a random number and determine if the HTML rowcol is filled and with what

if the rowcol is filled and with the random number value go to the next rowcol
else place the random number value in that rowcol

complete the if else statement a total of three times

wait for the trigger

end the runUpdate function until triggered



 */