/* Devin M. Woodfork
 2/29/16
 OBJECTS.Person Assignment
 */

//*********** PSEUDO CODE ONLY

/* create new object for people including an array for jobs and actions

   Person constructor should contain: name, job, action, row

   name includes the name of the person

   job includes the randomly selected job from jobs Array

   action includes what person is doing the randomly selected action

   row will be set in the Constructor

   create an update function

   Add the Person object to the global window "example: window.Person=Person"

   Jobs Array for Person Object: Painter, Drawer, Singer, Dancer, Photographer

   Actions Array for Person Object: Working, On Lunch, In Meeting, On the Phone, Driving

   Constructor for new persons (name, row)

   name: name of person
   action: randomly selected from actions Array
   job: randomly selected from jobs Array
   row: appropriate HTML row

   Update PROTOTYPE to change action of person
 */